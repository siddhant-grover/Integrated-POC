Steps in order->

->Mongod 
1.open new terminal
2.run command:mongod    eg. PS C:\Users\SIDDHANT\Desktop\node-react-ecommerce-POC> mongod

->mongodb.js
1.open new terminal
2.cd backend 
3.cd productManager
4.npm install
5.run command: node mongodb.js  eg.PS C:\Users\SIDDHANT\Desktop\node-react-ecommerce-POC\backend\productManager> node mongodb.js
NOTE->A. To populate data base before accessing the site with admin data and initial products , only run it once or products will be doubled
B. Run after backen and frontend server before accessing the site

->Run Backend
1.npm install eg. PS C:\Users\SIDDHANT\Desktop\node-react-ecommerce-POC>npm install
2.npm start
Server starts at http://localhost:5000

->Run Frontend
1.open new terminal
2.cd frontend
3.npm install  eg. PS C:\Users\SIDDHANT\Desktop\node-react-ecommerce-POC\frontend>npm install
4.npm start
5.if error then-> update react-scrits in frontend->npm install react-scripts@3.4.0
Server starts at http://localhost:3000


NOTE:restart the backend if products doesnt appear

Your site is up and running

Inside the site->
1.From the get go Signin with the Admin credentials to access,delete all orders ordered by each and every user,
You can create your own products or edit or delete existing products and add to the site .


Admin Credentials ->
Email:siddhantgroverboss@gmail.com
Password:1234
2.You can register a new user and signIn with it again to buy products and see previous order details.
Note(important):- When u register a new user , u r directed to homepage , if user(like user name) options are not displayed in the header, just refresh the site.


